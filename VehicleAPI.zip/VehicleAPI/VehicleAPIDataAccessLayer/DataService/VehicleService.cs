﻿using System;
using System.Collections.Generic;
using System.Linq;
using VehicleAPIDataAccessLayer.DataModel;

namespace VehicleAPIDataAccessLayer.DataService
{
    public class VehicleService : IVehicleRepository
    {
        // Creating and initialize list of vehicles to persist vehicle data in-memory
        private static readonly List<Vehicle> _vehicles = new List<Vehicle>()
        {
            new Vehicle{ Id = _getNextId(), Year = 2014 , Make = "Toyota", Model = "Corola"},
            new Vehicle{ Id = _getNextId(), Year = 2019 , Make = "Mini", Model = "Copper"}
        };
       
        private static int _id;

        // Unique Id generator
        private static int _getNextId()
        {
            return ++_id;
        }

        // Returns vehicle by id
        public Vehicle GetVehicleById(int id)
        {
            return _vehicles.Where(vehicle => vehicle.Id == id).FirstOrDefault();
        }

        // Returns vehicle list
        public IEnumerable<Vehicle> GetVehicleList(VehicleCriteria criteria)
        {
            var vehicles = !string.IsNullOrEmpty(criteria?.Make) ? _vehicles.Where(vehicle => vehicle.Make.Equals(criteria.Make, StringComparison.OrdinalIgnoreCase)) : _vehicles;
            vehicles = !string.IsNullOrEmpty(criteria?.Model) ? vehicles.Where(vehicle => vehicle.Model.Equals(criteria.Model, StringComparison.OrdinalIgnoreCase)) : vehicles;
            vehicles = criteria?.Year > 0 ? vehicles.Where(vehicle => vehicle.Year == criteria.Year) : vehicles;
            return vehicles.ToList();
        }

        // Adds new vehicle
        public Vehicle AddVehicle(Vehicle vehicle)
        {
            try
            {
                vehicle.Id = _getNextId();
                _vehicles.Add(vehicle);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return vehicle;
        }

        // Updates existing vehicle
        public bool UpdateVehicle(Vehicle vehicle)
        {
            var result = false;
            try
            {
                var updatedVehicle = _vehicles.Where(x => x.Id == vehicle.Id).FirstOrDefault();
                
                updatedVehicle.Year = vehicle.Year;
                updatedVehicle.Make = vehicle.Make;
                updatedVehicle.Model = vehicle.Model;
                result = true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return result;
        }

        // Deletes existing vehicle
        public bool DeleteVehicle(int id)
        {
            var result = false;
            try
            {
                var vehicle = _vehicles.Where(x => x.Id == id).SingleOrDefault();
                _vehicles.Remove(vehicle);
                result = true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return result;
        }
    }
}
