﻿using System.Collections.Generic;

namespace VehicleAPIDataAccessLayer.DataModel
{
    public interface IVehicleRepository
    {
        Vehicle GetVehicleById(int id);
        IEnumerable<Vehicle> GetVehicleList(VehicleCriteria criteria);
        Vehicle AddVehicle(Vehicle vehicle);
        bool UpdateVehicle(Vehicle vehicle);
        bool DeleteVehicle(int id);
    }
}
