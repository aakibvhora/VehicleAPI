using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using VehicleAPI.App_Start;
using VehicleAPI.BusinessLayer.Model;
using VehicleAPI.Controllers;
using VehicleAPI.Models;
using Xunit;

namespace VehicleAPI.Tests
{
    public class VehiclesControllerTests
    {
        private readonly VehiclesController _controller;
        private readonly IVehicleBusinessLayer _businessLayer;
        public VehiclesControllerTests()
        {
            _businessLayer = new BusinessLayerFake();
            _controller = new VehiclesController(_businessLayer);
            AutomapperStartUp.Configure();
        }

        [Fact]
        public void GetVehilceById_UnknownIdPassed_ReturnsNotFoundResult()
        {
            // Act
            var notFoundResult = _controller.GetVehilceById(4);

            // Assert
            Assert.IsType<NotFoundResult>(notFoundResult.Result);
        }

        [Fact]
        public void GetVehilceById_ExistingIdPassed_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.GetVehilceById(1);

            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        [Fact]
        public void GetVehilceById_ExistingIdPassed_ReturnsRightItem()
        {
            // Act
            var okResult = _controller.GetVehilceById(1).Result as OkObjectResult;

            // Assert
            Assert.IsType<Vehicle>(okResult.Value);
            Assert.Equal(1, (okResult.Value as Vehicle).Id);
        }

        [Fact]
        public void GetVehicles_WhenCalledWithoutVehicleGetCriteria_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.GetVehicles(null);

            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        [Fact]
        public void GetVehicles_WhenCalledWithoutVehicleGetCriteria_ReturnsAllItems()
        {
            // Act
            var okResult = _controller.GetVehicles(null).Result as OkObjectResult;

            // Assert
            var items = Assert.IsType<List<Vehicle>>(okResult.Value);
            Assert.Equal(3, items.Count);
        }

        [Fact]
        public void GetVehicles_WhenCalledWithValidVehicleGetCriteria_ReturnsMatchedItems()
        {
            // Arrange
            var criteria = new VehicleGetCriteria() 
            {
                Make = "Toyota"
            };

            // Act
            var okResult = _controller.GetVehicles(criteria).Result as OkObjectResult;

            // Assert
            var items = Assert.IsType<List<Vehicle>>(okResult.Value);
            Assert.Equal(2, items.Count);
        }



        [Fact]
        public void AddVehicle_ValidVehicleObjectPassed_ReturnsCreatedResponse()
        {
            // Arrange
            var vehicle = new Vehicle()
            {
                Make = "Toyota",
                Model = "Camry",
                Year = 2018
            };

            // Act
            var createdResponse = _controller.AddVehicle(vehicle);

            // Assert
            Assert.IsType<CreatedAtActionResult>(createdResponse);
        }

        [Fact]
        public void AddVehicle_ValidVehicleObjectPassed_ReturnedResponseHasCreatedItem()
        {
            // Arrange
            var vehicle = new Vehicle()
            {
                Make = "Toyota",
                Model = "Camry",
                Year = 2018
            };

            // Act
            var createdResponse = _controller.AddVehicle(vehicle) as CreatedAtActionResult;
            var item = createdResponse.Value as Vehicle;

            // Assert
            Assert.IsType<Vehicle>(item);
            Assert.Equal("Toyota", item.Make);
        }

        [Fact]
        public void AddVehicle_InCorrectDataPassed_ReturnsBadRequestObjectResultWithErrorMessage()
        {
            // Arrange
            var testVehicle = new Vehicle()
            {
                Year = 1840
            };
            var errorMessage = "The field Year must be between 1950 and 2050. The Make field is required. The Model field is required.";

            // Act
            var response = _controller.AddVehicle(testVehicle) as BadRequestObjectResult;

            // Assert
            Assert.Equal(errorMessage, response.Value);
        }

        [Fact]
        public void DeleteVehicleById_NotExistingIdPassed_ReturnsNotFoundResponse()
        {
            // Act
            var badResponse = _controller.DeleteVehicleById(4);

            // Assert
            Assert.IsType<NotFoundResult>(badResponse);
        }

        [Fact]
        public void DeleteVehicleById_ExistingIdPassed_ReturnsOkResult()
        {
            // Act
            var okResponse = _controller.DeleteVehicleById(2);

            // Assert
            Assert.IsType<OkResult>(okResponse);
        }

        [Fact]
        public void DeleteVehicleById_ExistingIdPassed_RemovesOneItem()
        {
            // Act
            _controller.DeleteVehicleById(2);

            // Assert
            Assert.Equal(2, _businessLayer.GetVehicleList(null).Count());
        }

        [Fact]
        public void UpdateVehicle_NotExistingVehiclePassed_ReturnsNotFoundResponse()
        {
            // Arrange
            var updateVehicle = new Vehicle()
            {
                Id = 10,
                Make = "Toyota",
                Model = "Camry",
                Year = 2018
            };

            // Act
            var response = _controller.UpdateVehicle(updateVehicle);

            // Assert
            Assert.IsType<NotFoundResult>(response);
        }

        [Fact]
        public void UpdateVehicle_ExistingVehiclePassed_ReturnsOkResult()
        {
            // Arrange
            var updateVehicle = new Vehicle()
            {
                Id = 2,
                Make = "Honda",
                Model = "Sonata",
                Year = 2018
            };

            // Act
            var response = _controller.UpdateVehicle(updateVehicle);

            // Assert
            Assert.IsType<OkResult>(response);
        }

        [Fact]
        public void UpdateVehicle_ExistingVehiclePassed_UpdateVehicle()
        {
            // Arrange
            var updateVehicle = new Vehicle()
            {
                Id = 2,
                Make = "Honda",
                Model = "Sonata",
                Year = 2018
            };

            // Act
            _controller.UpdateVehicle(updateVehicle);
            var updatedVehicle = _businessLayer.GetVehicleById(updateVehicle.Id);

            // Assert
            Assert.Equal(updateVehicle.Make, updatedVehicle.Make);
        }
    }
}
