﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using VehicleAPI.BusinessLayer.Model;
using VehicleAPI.BusinessLayer.Utility;
using VehicleAPIDataAccessLayer.DataModel;

namespace VehicleAPI.Tests
{
    public class BusinessLayerFake : IVehicleBusinessLayer
    {
        private readonly List<Vehicle> _vehicles = new List<Vehicle>()
            {
                new Vehicle() { Id=1, Make="Toyota", Model = "Corola", Year=2012  },
                new Vehicle() { Id=2, Make="Toyota", Model = "RAV4", Year=2019 },
                new Vehicle() { Id=3, Make="Honda", Model = "Sonata", Year=2018 }
            };
        private static int _id = 0;

        private static int _getNextId()
        {
            return ++_id;
        }

        public Vehicle GetVehicleById(int id)
        {
            return _vehicles.Where(vehicle => vehicle.Id == id).FirstOrDefault();
        }

        public IEnumerable<Vehicle> GetVehicleList(VehicleCriteria criteria)
        {
            var vehicles = !string.IsNullOrEmpty(criteria?.Make) ? _vehicles.Where(vehicle => vehicle.Make.Equals(criteria.Make, StringComparison.OrdinalIgnoreCase)) : _vehicles;
            vehicles = !string.IsNullOrEmpty(criteria?.Model) ? vehicles.Where(vehicle => vehicle.Model.Equals(criteria.Model, StringComparison.OrdinalIgnoreCase)) : vehicles;
            vehicles = criteria?.Year > 0 ? vehicles.Where(vehicle => vehicle.Year == criteria.Year) : vehicles;
            return vehicles.ToList();
        }

        public Vehicle AddVehicle(Vehicle vehicle)
        {
            var message = Validate.ValidateVehicle(vehicle);
            if (message.Length > 0)
            {
                throw new InvalidDataException(message.ToString().Trim());
            }
            vehicle.Id = _getNextId();
            _vehicles.Add(vehicle);
            return vehicle;
        }

        public bool DeleteVehicle(int id)
        {
            var existing = _vehicles.First(a => a.Id == id);
            _vehicles.Remove(existing);
            return true;
        }



        public bool UpdateVehicle(Vehicle vehicle)
        {
            var updatedVehicle = _vehicles.Where(x => x.Id == vehicle.Id).SingleOrDefault();
            updatedVehicle.Year = vehicle.Year;
            updatedVehicle.Make = vehicle.Make;
            updatedVehicle.Model = vehicle.Model;
            return true;
        }
    }
}
