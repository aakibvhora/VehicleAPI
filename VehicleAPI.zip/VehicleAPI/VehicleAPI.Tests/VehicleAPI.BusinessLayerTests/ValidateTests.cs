﻿using System;
using System.Collections.Generic;
using System.Text;
using VehicleAPI.BusinessLayer.Utility;
using VehicleAPIDataAccessLayer.DataModel;
using Xunit;

namespace VehicleAPI.Tests.VehicleAPI.BusinessLayerTests
{
    public class ValidateTests
    {
        [Fact]
        public void Validate_WhenCalledWithIncorrectData_ReturnsErrorMessage()
        {
            // Arrange
            var vehicle = new Vehicle()
            {
                Year=1850,
            };
            var errorMessage = "The field Year must be between 1950 and 2050. The Make field is required. The Model field is required.";


            // Act
            var message = Validate.ValidateVehicle(vehicle);

            // Assert
            Assert.Equal(errorMessage, message.ToString().Trim());
        }

        [Fact]
        public void Validate_WhenCalledWithCorrectData_ReturnsEmptyString()
        {
            // Arrange
            var vehicle = new Vehicle()
            {
                Year = 2019,
                Make = "Fake Make",
                Model = "Fake Model"
            };

            // Act
            var message = Validate.ValidateVehicle(vehicle);

            // Assert
            Assert.Equal(0, message.Length);
        }
    }
}
