﻿using AutoMapper;
using VehicleAPI.Models;
using DATAMODEL = VehicleAPIDataAccessLayer.DataModel;

namespace VehicleAPI.App_Start
{
    public static class AutomapperStartUp
    {
        private static bool _isConfigured;
        private static readonly object LockObject = new object();
        public static void Configure()
        {
            lock (LockObject)
            {
                if (!_isConfigured)
                {
                    Mapper.Initialize(configExpression =>
                    {
                        configExpression.CreateMap<DATAMODEL.Vehicle, Vehicle>();
                        configExpression.CreateMap<DATAMODEL.VehicleCriteria, VehicleGetCriteria>();
                    });

                    _isConfigured = true;
                }
            }
        }
    }
}
