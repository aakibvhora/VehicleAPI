﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using VehicleAPI.BusinessLayer.Model;
using VehicleAPI.Models;
using DATAMODEL = VehicleAPIDataAccessLayer.DataModel;

namespace VehicleAPI.Controllers
{
    [ApiController]
    public class VehiclesController : ControllerBase
    {
        private readonly IVehicleBusinessLayer _businessLayer;

        public VehiclesController(IVehicleBusinessLayer businessLayer)
        {
            _businessLayer = businessLayer;
        }

        // Retrieves vehicle information based on given id
        [Route("vehicles/{id}")]
        [HttpGet]
        public ActionResult<Vehicle> GetVehilceById(int id)
        {
            var vehicle = Mapper.Map<Vehicle>(_businessLayer.GetVehicleById(id));
            if (vehicle == null)
            {
                return NotFound();
            }
            return Ok(vehicle);
        }

        /*  Retrieves vehicles information based on given criteria given in request query,
            otherwise returns all vehicles information  */
        [Route("vehicles/")]
        [HttpGet]
        public ActionResult<IEnumerable<Vehicle>> GetVehicles([FromQuery] VehicleGetCriteria criteria)
        {
            var vehicles = Mapper.Map<List<Vehicle>>(_businessLayer.GetVehicleList(Mapper.Map<DATAMODEL.VehicleCriteria>(criteria)));
            if (vehicles?.Count <= 0)
            {
                return NotFound();
            }
            return Ok(vehicles);
        }

        // Add new vehicle information
        [Route("vehicles/")]
        [HttpPost]
        public ActionResult AddVehicle([FromBody]Vehicle vehicle)
        {
            try
            {
                var newVehicle = Mapper.Map<Vehicle>(_businessLayer.AddVehicle(Mapper.Map<DATAMODEL.Vehicle>(vehicle)));
                return CreatedAtAction("GetVehilceById", new { id = newVehicle.Id }, newVehicle);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }

        // Update existing vehicle information
        [Route("vehicles/")]
        [HttpPut]
        public ActionResult UpdateVehicle([FromBody]Vehicle vehicle)
        {
            var existingVehicle = _businessLayer.GetVehicleById(vehicle.Id);
            if (existingVehicle == null)
            {
                return NotFound();
            }
            
            _businessLayer.UpdateVehicle(Mapper.Map<DATAMODEL.Vehicle>(vehicle));
            return Ok();
        }

        // Delete exisitng vehicle information
        [Route("vehicles/{id}")]
        [HttpDelete]
        public ActionResult DeleteVehicleById(int id)
        {
            var existingVehicle = _businessLayer.GetVehicleById(id);
            if(existingVehicle == null)
            {
                return NotFound();
            }

           _businessLayer.DeleteVehicle(id);
            return Ok();
        }
    }
}
