﻿using System.Collections.Generic;
using VehicleAPIDataAccessLayer.DataModel;

namespace VehicleAPI.BusinessLayer.Model
{
    public interface IVehicleBusinessLayer
    {
        Vehicle GetVehicleById(int id);
        IEnumerable<Vehicle> GetVehicleList(VehicleCriteria criteria);
        Vehicle AddVehicle(Vehicle vehicle);
        bool UpdateVehicle(Vehicle vehicle);
        bool DeleteVehicle(int id);
    }
}
