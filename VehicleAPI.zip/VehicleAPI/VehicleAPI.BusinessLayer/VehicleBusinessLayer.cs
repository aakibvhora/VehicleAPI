﻿using System.Collections.Generic;
using System.IO;
using VehicleAPI.BusinessLayer.Model;
using VehicleAPI.BusinessLayer.Utility;
using VehicleAPIDataAccessLayer.DataModel;

namespace VehicleAPI.BusinessLayer
{
    public class VehicleBusinessLayer : IVehicleBusinessLayer
    {
        private readonly IVehicleRepository _repository;

        public VehicleBusinessLayer(IVehicleRepository repository)
        {
            _repository = repository;
        }

        public Vehicle GetVehicleById(int id)
        {
            return _repository.GetVehicleById(id);
        }

        public IEnumerable<Vehicle> GetVehicleList(VehicleCriteria criteria)
        {
            return _repository.GetVehicleList(criteria);
        }

        public Vehicle AddVehicle(Vehicle vehicle)
        {
            var message = Validate.ValidateVehicle(vehicle);
            if (message.Length > 0)
            {
                throw new InvalidDataException(message.ToString().Trim());
            }
            return _repository.AddVehicle(vehicle);
        }

        public bool UpdateVehicle(Vehicle vehicle)
        {
            var message = Validate.ValidateVehicle(vehicle);
            if (message.Length > 0)
            {
                throw new InvalidDataException(message.ToString().Trim());
            }
            return _repository.UpdateVehicle(vehicle);
        }

        public bool DeleteVehicle(int id)
        {
            return _repository.DeleteVehicle(id);
        }
    }
}
