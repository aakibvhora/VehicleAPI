﻿using System.Text;
using VehicleAPIDataAccessLayer.DataModel;

namespace VehicleAPI.BusinessLayer.Utility
{
    public static class Validate
    {
        // Validate vehicle object with business rules.
        public static StringBuilder ValidateVehicle(Vehicle vehicle)
        {
            var result = new StringBuilder();
            if (vehicle.Year < 1950 || vehicle.Year > 2050)
            {
                result.Append("The field Year must be between 1950 and 2050. ");
            }
            if (string.IsNullOrEmpty(vehicle.Make))
            {
                result.Append("The Make field is required. ");
            }
            if (string.IsNullOrEmpty(vehicle.Model))
            {
                result.Append("The Model field is required.");
            }
            return result;
        }
    }
}
